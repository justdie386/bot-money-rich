local sql = require "ljsqlite3"
local conn = sql.open("data.sqlite")
if check == 5 then
    local success, err = interaction:reply(Beau)
if err then print(err) end
local check = 0
Beau = " "
end

OTMwMjc5OTcxOTgzODgwMjAz.G3Mf6Y.0UeYYfUFg5J8oP9BWY7K0pQPe7tpWs3_y4Lh9M
 OTMwMjc5OTcxOTgzODgwMjAz.GpYHBU.e_HmsnlS5aTMVN55JEq8udukeEekQUB50i_XJ0